package com.mickey.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mickey.pojo.Entity.AdminInfo;

public interface RegisterMapper extends BaseMapper<AdminInfo> {

}
