package com.mickey.service.interview;

import com.mickey.DTO.AdminInfoDTO;
import com.mickey.Entity.AdminInfo;
import com.mickey.VO.AdminInfoVO;
import org.springframework.stereotype.Service;

public interface RegisterService {
    AdminInfoVO saveAdmin(AdminInfoDTO adminInfoDTO);
    boolean usernameExists(String username);
}
