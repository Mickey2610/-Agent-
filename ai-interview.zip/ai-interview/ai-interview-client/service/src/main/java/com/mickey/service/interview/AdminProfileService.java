package com.mickey.service.interview;

import com.mickey.DTO.AdminInfoDTO;
import com.mickey.DTO.ChangePasswordDTO;
import com.mickey.Entity.AdminInfo;
import com.mickey.VO.AdminInfoVO;
import jakarta.servlet.http.HttpServletRequest;

public interface AdminProfileService {
    AdminInfoVO updateProfile(HttpServletRequest request, AdminInfoDTO updateInfoDTO);
    AdminInfoVO setProfile (HttpServletRequest request);
    Integer changePassword (HttpServletRequest request, ChangePasswordDTO changePasswordDTO);
}
