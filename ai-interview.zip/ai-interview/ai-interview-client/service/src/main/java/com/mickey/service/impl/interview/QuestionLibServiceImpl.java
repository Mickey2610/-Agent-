package com.mickey.service.impl.interview;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.mickey.DTO.QuestionLibDTO;
import com.mickey.Entity.QuestionLib;
import com.mickey.VO.InitQuestionLibVO;
import com.mickey.VO.QuestionLibVO;
import com.mickey.base.BaseInfoProperties;
import com.mickey.enums.YesOrNo;
import com.mickey.mapper.QuestionLibMapper;
import com.mickey.mapper.QuestionLibMapperCustom;
import com.mickey.service.interview.CandidateService;
import com.mickey.service.interview.JobService;
import com.mickey.service.interview.QuestionLibService;
import com.mickey.utils.PagedGridResult;
import jakarta.annotation.Resource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class QuestionLibServiceImpl extends BaseInfoProperties implements QuestionLibService {
    @Resource
    QuestionLibMapper questionLibMapper;
    @Resource
    private QuestionLibMapperCustom questionLibMapperCustom;
    @Resource
    private JobService jobService;
    @Autowired
    private CandidateService candidateService;

    @Override
    public void createOrUpdate(QuestionLibDTO questionLibDTO) {

        QuestionLib questionLib = new QuestionLib();
        BeanUtils.copyProperties(questionLibDTO, questionLib);
        questionLib.setUpdatedTime(LocalDateTime.now());

        if (StringUtils.isBlank(questionLib.getId())) {
            questionLib.setCreateTime(LocalDateTime.now());
            questionLib.setIsOn(YesOrNo.YES.type);
            questionLibMapper.insert(questionLib);
        } else {
            questionLibMapper.updateById(questionLib);
        }

    }

    @Override
    public PagedGridResult queryList(String aiName, String question, Integer page, Integer pageSize) {
        PageHelper.startPage(page, pageSize);
        Map<String, Object> map = new HashMap<>();
        if (StringUtils.isNotBlank(aiName)) {
            map.put("aiName", aiName);
        }
        if (StringUtils.isNotBlank(question)) {
            map.put("question", question);
        }
        List<QuestionLibVO> list = questionLibMapperCustom.queryQuestionLibList(map);
        return setterPagedGrid(list, page);
    }

    @Override
    public void setDisplayOrNot(String QuestionLibId, Integer isOn) {
        QuestionLib questionLib = new QuestionLib();
        questionLib.setId(QuestionLibId);
        questionLib.setIsOn(isOn);
        questionLib.setUpdatedTime(LocalDateTime.now());
        questionLibMapper.updateById(questionLib);
    }

    @Override
    public void delete(String QuestionLibId) {
        questionLibMapper.deleteById(QuestionLibId);
    }

    @Override
    public boolean isQuestionContainInterviewer(String interviewerId) {
        QueryWrapper<QuestionLib> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("interviewer_id", interviewerId);
        Long counts = questionLibMapper.selectCount(queryWrapper);
        return counts > 0;
    }

    @Override
    public List<InitQuestionLibVO> getInitQuestionLib(String candidateId, Integer questionNum) {
        // 1. 根据应聘者ID获取其岗位ID
        String jobId = candidateService.getDetail(candidateId).getJobId();

        // 2. 根据岗位ID获取对应的面试官ID
        String interviewerId = jobService.getDetail(jobId).getInterviewerId();

        // 3. 查询题库中已启用题目的总数量
        Long questionCounts = questionLibMapper.selectCount(
                new QueryWrapper<QuestionLib>()
                        .eq("is_on", 1));

        // 4. 初始化随机数列表，用于存储已选的题目索引，防止重复
        List<Long> randomList = new ArrayList<>();

        // 5. 定义查询参数和最终返回的题目列表
        Map<String, Object> map = new HashMap<>();
        List<InitQuestionLibVO> questionList = new ArrayList<>();

        // 6. 循环获取 questionNum 道不重复、且属于当前面试官的题目
        for (int i = 0; i < questionNum; i++) {
            Random r = new Random(); // 【注意】每次循环都新建 Random 对象，效率偏低

            Long randomNum = r.nextLong(questionCounts); // 生成 [0, questionCounts) 范围内的随机数

            // 6.1 若随机数重复，则增加循环次数以补偿，并跳过本次
            if (randomList.contains(randomNum)) {
                questionNum++;
                continue;
            }

            // 6.2 将当前随机数加入已选列表
            randomList.add(randomNum);

            // 6.3 查询对应索引的题目
            map.put("indexNum", randomNum);
            InitQuestionLibVO question = questionLibMapperCustom.queryRandomQuestionLib(map);

            // 6.4 检查该题目是否属于当前面试官，若不属于，则增加循环次数以补偿，并跳过本次
            String interviewerId2 = question.getInterviewerId();
            if (!Objects.equals(interviewerId2, interviewerId)) {
                questionNum++;
                continue;
            }

            // 6.5 将符合要求的题目加入返回列表
            questionList.add(question);
        }

        // 7. 返回最终题目列表
        return questionList;
    }

}
