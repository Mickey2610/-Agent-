package com.mickey.service.impl.interview;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.mickey.DTO.JobDTO;
import com.mickey.Entity.Job;
import com.mickey.VO.JobVO;
import com.mickey.base.BaseInfoProperties;
import com.mickey.mapper.JobMapper;
import com.mickey.mapper.JobMapperCustom;
import com.mickey.mapper.QuestionLibMapper;
import com.mickey.service.interview.JobService;
import com.mickey.utils.PagedGridResult;
import jakarta.annotation.Resource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

@Service
public class JobServiceImpl extends BaseInfoProperties implements JobService {

    @Resource
    JobMapper jobMapper;

    @Resource
    JobMapperCustom jobMapperCustom;
    @Autowired
    private QuestionLibMapper questionLibMapper;

    @Override
    public void createOrUpdate(JobDTO jobDTO) {
        Job job = new Job();
        BeanUtils.copyProperties(jobDTO, job);
        job.setCreateTime(LocalDateTime.now());
        if (StringUtils.isBlank(job.getId())) {
            job.setUpdatedTime(LocalDateTime.now());
            jobMapper.insert(job);
        } else {
            jobMapper.updateById(job);
        }
    }

    @Override
    public PagedGridResult queryList(Integer page, Integer pageSize) {

        PageHelper.startPage(page, pageSize);
        List<JobVO> jobVOList = jobMapperCustom.queryJobLibList(null);
        return setterPagedGrid(jobVOList, page);
    }

    @Override
    public Job getDetail(String jobId) {
        Job detail = jobMapper.selectById(jobId);
        return detail;
    }

    @Override
    public void delete(String jobId) {
        jobMapper.deleteById(jobId);
    }

    @Override
    public boolean isJobContainInterviewer(String InterviewerId) {
        // 1. 创建 QueryWrapper 实例，指定泛型为 Job（对应数据库表）
        QueryWrapper<Job> queryWrapper = new QueryWrapper<>();
        // 2. 添加查询条件：interviewer_id 字段等于传入的 InterviewerId
        queryWrapper.eq("interviewer_id", InterviewerId);
        // 3. 使用 Mapper 查询符合条件的记录数
        Long counts = jobMapper.selectCount(queryWrapper);
        // 4. 返回是否存在记录（count > 0）
        return counts > 0;
    }

    @Override
    public List<HashMap<String, String>> nameList() {
        List<HashMap<String, String>> hashMaps = jobMapperCustom.queryNameList(null);
        return hashMaps;
    }
}
