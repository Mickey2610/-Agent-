package com.mickey.service.impl.interview;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.mickey.DTO.Top10DTO;
import com.mickey.Entity.Candidate;
import com.mickey.VO.CandidateReportVO;
import com.mickey.VO.Top10VO;
import com.mickey.mapper.CandidateMapper;
import com.mickey.mapper.InterviewRecordMapperCustom;
import com.mickey.service.interview.AnalysisService;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AnalysisServiceImpl implements AnalysisService {

    @Autowired
    private InterviewRecordMapperCustom interviewRecordMapperCustom;
    @Autowired
    private CandidateMapper candidateMapper;

    @Override
    public Top10VO getInterviewTopScores(LocalDate begin, LocalDate end) {
        LocalDateTime beginTime = LocalDateTime.of(begin, LocalTime.MIN);
        LocalDateTime endTime = LocalDateTime.of(end, LocalTime.MAX);

        // 假设有一个自定义Mapper方法获取面试分数前十
        List<Top10DTO> topScores = interviewRecordMapperCustom.getInterviewTop10(beginTime, endTime);

        String nameList = StringUtils.join(
                topScores.stream()
                        .map(Top10DTO::getRealName)
                        .collect(Collectors.toList()),
                ","
        );

        String scoreList = StringUtils.join(
                topScores.stream()
                        .map(Top10DTO::getScore)
                        .collect(Collectors.toList()),
                ","
        );
        return Top10VO.builder()
                .nameList(nameList)
                .scoreList(scoreList)
                .build();
    }

    @Override
    public CandidateReportVO getCandidateReport(LocalDate begin, LocalDate end) {
        List<LocalDate> dataList = new ArrayList<>();
        LocalDate currentDate = begin;

        while (!currentDate.isAfter(end)) {
            dataList.add(currentDate);
            currentDate = currentDate.plusDays(1);
        }

        List<Integer> newCandidateList = new ArrayList<>(); // 每天新增人数
        List<Integer> totalCandidateList = new ArrayList<>(); // 每天累计人数

        int cumulativeTotal = 0; // 累计人数

        for (LocalDate date : dataList) {
            Integer dailyCount = getCandidateCount(date, date); // 查询当天新增
            newCandidateList.add(dailyCount);

            cumulativeTotal += dailyCount;
            totalCandidateList.add(cumulativeTotal);
        }

        return CandidateReportVO.builder()
                .dataList(StringUtils.join(dataList, ","))
                .newCandidateList(StringUtils.join(newCandidateList, ","))
                .totalCandidateList(StringUtils.join(totalCandidateList, ","))
                .build();
    }

    @Override
    public XSSFWorkbook exportAnalysisReport(LocalDate begin, LocalDate end) throws Exception {
        // 1. 加载模板文件
        InputStream inputStream = this.getClass().getClassLoader()
                .getResourceAsStream("template/AI面试模板.xlsx");

        if (inputStream == null) {
            throw new RuntimeException("找不到报表模板文件，请检查 template/分析报表模板.xlsx");
        }

        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
        // 创建居中样式
        XSSFCellStyle centerStyle = workbook.createCellStyle();
        centerStyle.setAlignment(HorizontalAlignment.CENTER);
        centerStyle.setVerticalAlignment(VerticalAlignment.CENTER);

        // 2. 填充 Sheet1: 面试分数Top10
        XSSFSheet sheet1 = workbook.getSheet("面试分数Top10");
        if (sheet1 == null) {
            throw new RuntimeException("Excel 模板中缺少名为 '面试分数Top10' 的 Sheet");
        }

        LocalDateTime beginTime = LocalDateTime.of(begin, LocalTime.MIN);
        LocalDateTime endTime = LocalDateTime.of(end, LocalTime.MAX);
        List<Top10DTO> topScores = interviewRecordMapperCustom.getInterviewTop10(beginTime, endTime);

        int rowNum = 4;
        for (Top10DTO dto : topScores) {
            XSSFRow row = sheet1.createRow(rowNum++);
            // 序号列
            XSSFCell cell0 = row.createCell(0);
            cell0.setCellValue(rowNum-4);
            cell0.setCellStyle(centerStyle);

            // 姓名列
            XSSFCell cell1 = row.createCell(1);
            cell1.setCellValue(dto.getRealName());
            cell1.setCellStyle(centerStyle);

            // 分数列
            XSSFCell cell2 = row.createCell(2);
            cell2.setCellValue(dto.getScore());
            cell2.setCellStyle(centerStyle);
        }

        // 3. 填充 Sheet2: 新增应聘者趋势
        XSSFSheet sheet2 = workbook.getSheet("新增应聘者报告");
        if (sheet2 == null) {
            throw new RuntimeException("Excel 模板中缺少名为 '新增应聘者报告' 的 Sheet");
        }

        List<LocalDate> dataList = new ArrayList<>();
        LocalDate currentDate = begin;

        while (!currentDate.isAfter(end)) {
            dataList.add(currentDate);
            currentDate = currentDate.plusDays(1);
        }

        int cumulativeTotal = 0; // 累计人数
        int currentColumn = 0; // 初始列索引为D列
        int maxRowsPerColumn = 16; // 每列最大行数
        int currentRow = 5; // 初始行索引为第4行

        for (LocalDate date : dataList) {
            Integer dailyCount = getCandidateCount(date, date); // 查询当天新增

            if (currentRow > 4 + maxRowsPerColumn) { // 如果当前行超过15行，则换到下一列
                currentColumn += 3; // 跳过三列（日期、新增人数、累计人数）
                currentRow = 5; // 重置行索引为第4行
            }

            XSSFRow row = sheet2.getRow(currentRow - 1);
            if (row == null) {
                row = sheet2.createRow(currentRow - 1);
            }

            // 日期列
            XSSFCell dateCell = row.createCell(currentColumn);
            dateCell.setCellValue(date.toString());
            dateCell.setCellStyle(centerStyle);

            // 新增人数列
            XSSFCell newCountCell = row.createCell(currentColumn + 1);
            newCountCell.setCellValue(dailyCount);
            newCountCell.setCellStyle(centerStyle);

            // 累计人数列
            cumulativeTotal += dailyCount;
            XSSFCell totalCountCell = row.createCell(currentColumn + 2);
            totalCountCell.setCellValue(cumulativeTotal);
            totalCountCell.setCellStyle(centerStyle);

            currentRow++;
        }

        return workbook;
    }


    private Integer getCandidateCount(LocalDate begin, LocalDate end) {
        QueryWrapper<Candidate> queryWrapper = new QueryWrapper<>();

        if (begin != null) {
            queryWrapper.ge("created_time", begin.atStartOfDay());
        }
        if (end != null) {
            queryWrapper.le("created_time", end.atTime(23, 59, 59));
        }

        Long count = candidateMapper.selectCount(queryWrapper);
        return count != null ? count.intValue() : 0;
    }
}
