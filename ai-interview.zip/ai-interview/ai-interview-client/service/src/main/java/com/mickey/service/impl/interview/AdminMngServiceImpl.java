package com.mickey.service.impl.interview;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.mickey.Entity.AdminInfo;
import com.mickey.Entity.Interviewer;
import com.mickey.VO.AdminInfoVO;
import com.mickey.mapper.RegisterMapper;
import com.mickey.mapper.RegisterMapperCustom;
import com.mickey.service.interview.AdminMngService;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminMngServiceImpl implements AdminMngService {
    @Resource
    private RegisterMapper registerMapper;
    @Autowired
    private RegisterMapperCustom registerMapperCustom;

    @Override
    public List<AdminInfo> queryAllAdminInfo() {
        return registerMapper.selectList(
                new QueryWrapper<AdminInfo>()
                        .orderByDesc("updated_at")
        );
    }
    @Override
    public void delete(String username) {
        AdminInfo adminInfo = registerMapperCustom.selectAdminInfoByName(username);
        registerMapper.deleteById(adminInfo.getId());
    }

    @Override
    public void updateStatus(String username, Boolean isEnabled) {
        AdminInfo adminInfo = registerMapperCustom.selectAdminInfoByName(username);
        adminInfo.setIsEnabled(isEnabled);
        registerMapper.updateById(adminInfo);
    }
}
