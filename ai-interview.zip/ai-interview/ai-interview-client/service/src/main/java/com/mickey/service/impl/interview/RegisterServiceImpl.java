package com.mickey.service.impl.interview;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.mickey.DTO.AdminInfoDTO;
import com.mickey.Entity.AdminInfo;
import com.mickey.VO.AdminInfoVO;
import com.mickey.mapper.RegisterMapper;
import com.mickey.service.interview.RegisterService;
import jakarta.annotation.Resource;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class RegisterServiceImpl implements RegisterService {

    @Resource
    private RegisterMapper registerMapper;
    @Override
    public AdminInfoVO saveAdmin(AdminInfoDTO adminInfoDTO) {
        // 构造 AdminInfo 对象
        AdminInfo adminInfo = new AdminInfo();
        AdminInfoVO adminInfoVO = new AdminInfoVO();
        BeanUtils.copyProperties(adminInfoDTO, adminInfo);
        // 自动设置为当前日期
        adminInfo.setCreatedAt(LocalDate.now());
        adminInfo.setRole(1);
        registerMapper.insert(adminInfo);
        BeanUtils.copyProperties(adminInfo, adminInfoVO);
        return adminInfoVO;
    }

    @Override
    public boolean usernameExists(String username) {
        List<AdminInfo> list = registerMapper.selectList(
                new QueryWrapper<AdminInfo>()
                        .eq("username",username)
        );

        if (list.isEmpty() || list.size() == 0) return false;

        return true;
    }
}
