package com.mickey.service.interview;

import com.mickey.DTO.QuestionLibDTO;
import com.mickey.VO.InitQuestionLibVO;
import com.mickey.utils.PagedGridResult;

import java.util.List;

public interface QuestionLibService {
    void createOrUpdate(QuestionLibDTO questionLibDTO);

    PagedGridResult queryList(String aiName, String question, Integer page, Integer pageSize);

    void setDisplayOrNot(String QuestionLibId, Integer isOn);

    void delete(String QuestionLibId);

    boolean isQuestionContainInterviewer(String interviewerId);

    List<InitQuestionLibVO> getInitQuestionLib(String candidateId, Integer questionNumber);
}