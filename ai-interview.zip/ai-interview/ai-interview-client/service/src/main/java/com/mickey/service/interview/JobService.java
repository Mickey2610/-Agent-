package com.mickey.service.interview;

import com.mickey.DTO.JobDTO;
import com.mickey.Entity.Job;
import com.mickey.utils.PagedGridResult;

import java.util.HashMap;
import java.util.List;

public interface JobService {
    void createOrUpdate(JobDTO jobDTO);

    PagedGridResult queryList(Integer page, Integer pageSize);

    Job getDetail(String jobId);

    void delete(String jobId);

    boolean isJobContainInterviewer(String InterviewerId);

    List<HashMap<String, String>> nameList();
}
