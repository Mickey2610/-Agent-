package com.mickey.service.interview;

import com.mickey.DTO.InterviewerDTO;
import com.mickey.Entity.Interviewer;

import java.util.List;


public interface InterviewerService {
    void createOrUpdate(InterviewerDTO interviewerDTO);

    List<Interviewer> queryAll();

    void delete(String id);
}
