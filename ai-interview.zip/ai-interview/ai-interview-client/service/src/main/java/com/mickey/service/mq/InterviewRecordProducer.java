package com.mickey.service.mq;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mickey.DTO.SubmitAnswerDTO;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InterviewRecordProducer {

    @Autowired
    private RocketMQTemplate rocketMQTemplate;

    public void sendSubmitAnswerMessage(SubmitAnswerDTO submitAnswerDTO) throws JsonProcessingException {
        // 将 SubmitAnswerDTO 转换成 JSON 字符串
        String jsonString = new ObjectMapper().writeValueAsString(submitAnswerDTO);
        // 发送消息到 DEEPSEEK_ANALYSIS_TOPIC
        rocketMQTemplate.convertAndSend("DEEPSEEK_ANALYSIS_TOPIC", jsonString);
    }
}