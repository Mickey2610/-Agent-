package com.mickey.service.interview;

import jakarta.servlet.http.HttpServletRequest;

public interface AdminLoginService {
    Boolean passwordMatch(String password, String username);
    void deleteRedis (HttpServletRequest request);
}
