package com.mickey.service.impl.interview;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.mickey.DTO.CandidateDTO;
import com.mickey.Entity.Candidate;
import com.mickey.VO.CandidateVO;
import com.mickey.base.BaseInfoProperties;
import com.mickey.mapper.CandidateMapper;
import com.mickey.mapper.CandidateMapperCustom;
import com.mickey.service.interview.CandidateService;
import com.mickey.utils.PagedGridResult;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CandidateServiceImpl extends BaseInfoProperties implements CandidateService {

    @Autowired
    private CandidateMapper candidateMapper;

    @Autowired
    private CandidateMapperCustom candidateMapperCustom;

    @Override
    public void createOrUpdate(CandidateDTO candidateDTO) {
        Candidate candidate = new Candidate();
        BeanUtils.copyProperties(candidateDTO, candidate);
        candidate.setUpdatedTime(LocalDateTime.now());

        if (StringUtils.isEmpty(candidateDTO.getId())) {
            candidate.setCreatedTime(LocalDateTime.now());
            candidateMapper.insert(candidate);
        } else {
            candidateMapper.updateById(candidate);
        }
    }

    @Override
    public PagedGridResult queryList(String realName, String mobile, Integer page, Integer pageSize) {

        PageHelper.startPage(page, pageSize);

        Map<String, Object> map = new HashMap<>();
        if (!(StringUtils.isBlank(realName))) {
            map.put("realName", realName);
        }
        if (!(StringUtils.isBlank(mobile))) {
            map.put("mobile", mobile);
        }

        List<CandidateVO> list = candidateMapperCustom.queryCandidateList(map);
        return setterPagedGrid(list, page);
    }

    @Override
    public void delete(String id) {
        candidateMapper.deleteById(id);
    }

    @Override
    public Candidate getDetail(String id) {
        return candidateMapper.selectById(id);
    }

    @Override
    public Candidate queryMobileIsExist(String mobile) {
        QueryWrapper<Candidate> wrapper = new QueryWrapper<>();
        QueryWrapper<Candidate> mobile1 = wrapper.eq("mobile", mobile);
        return candidateMapper.selectOne(mobile1);
    }
}
