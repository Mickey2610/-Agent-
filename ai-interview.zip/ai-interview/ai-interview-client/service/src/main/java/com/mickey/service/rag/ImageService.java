package com.mickey.service.rag;

import com.mickey.Entity.ChatEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface ImageService {
    public void analyzeImage(List<MultipartFile> file, ChatEntity chatEntity);
}
