package com.mickey.service.rag;

import org.springframework.ai.document.Document;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface DocumentService {

    /**
     * @Description: 加载文档并且读取数据进行保存到知识库
     * @Author 风间影月
     * @param fileName
     */
    public List<Document> loadTxtText(Resource resource, String fileName);

    public List<Document> loadOtherText(MultipartFile file);

    /**
     * @Description: 根据提问从知识库中查询相应的知识/资料（相似）
     * @Author 风间影月
     * @param question
     * @return List<Document>
     */
    public List<Document> doSearch(String question);

}
