package com.mickey.service.impl.rag;

import com.mickey.service.rag.DocumentService;
import com.mickey.utils.CustomTextSplitter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.TextReader;
import org.springframework.ai.reader.tika.TikaDocumentReader;
import org.springframework.ai.vectorstore.redis.RedisVectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @ClassName DocumentServiceImpl
 * @Author 风间影月
 * @Version 1.0
 * @Description DocumentServiceImpl
 **/
@Slf4j
@Service
//@RequiredArgsConstructor // 为了避免@Resource和Resource类冲突
public class DocumentServiceImpl implements DocumentService {

    private final RedisVectorStore redisVectorStore;
//     使用构造函数注入
    public DocumentServiceImpl(RedisVectorStore redisVectorStore) {
        this.redisVectorStore = redisVectorStore;
    }
    @Override
    public List<Document> loadTxtText(Resource resource, String fileName) {

        // 加载读取文档
        TextReader textReader = new TextReader(resource);
        textReader.getCustomMetadata().put("fileName", fileName);
        textReader.getCustomMetadata().put("charset", StandardCharsets.UTF_8);
        List<Document> documentList = textReader.get();
        //默认的文本切分器
//        TokenTextSplitter tokenTextSplitter = new TokenTextSplitter();
//        List<Document> list = tokenTextSplitter.apply(documentList);

        CustomTextSplitter tokenTextSplitter = new CustomTextSplitter();
        List<Document> list = tokenTextSplitter.apply(documentList);

        System.out.println("list = " + list);

        // 向量存储
        redisVectorStore.add(list);

        return documentList;
    }

    @Override
    public List<Document> loadOtherText(MultipartFile file) {
        TikaDocumentReader tikaDocumentReader = new TikaDocumentReader(file.getResource());
        List<Document> document = tikaDocumentReader.get();
        List<Document> documentList = document.stream()
                .map(doc -> {
                    return new Document(doc.getFormattedContent()); // assuming Document has such constructor
                })
                .collect(Collectors.toList());
        CustomTextSplitter tokenTextSplitter = new CustomTextSplitter();
        List<Document> list = tokenTextSplitter.apply(documentList);

        System.out.println("list = " + list);

        // 向量存储
        redisVectorStore.add(list);
        return documentList;
    }

    @Override
    public List<Document> doSearch(String question) {
        return redisVectorStore.similaritySearch(question);
    }
}
