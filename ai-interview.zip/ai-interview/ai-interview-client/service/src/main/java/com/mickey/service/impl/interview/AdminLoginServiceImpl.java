package com.mickey.service.impl.interview;

import com.mickey.Entity.AdminInfo;
import com.mickey.grace.result.GraceJSONResult;
import com.mickey.mapper.RegisterMapper;
import com.mickey.mapper.RegisterMapperCustom;
import com.mickey.service.interview.AdminLoginService;
import com.mickey.utils.RedisOperator;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.mickey.base.BaseInfoProperties.REDIS_ADMIN_INFO;

@Service
public class AdminLoginServiceImpl implements AdminLoginService {
    @Resource
    private RegisterMapperCustom registerMapperCustom;
    @Resource
    public RedisOperator redis;
    @Override
    public Boolean passwordMatch(String password, String username) {
        AdminInfo adminInfo = registerMapperCustom.selectAdminInfoByName(username);
        String password1 = adminInfo.getPassword();
        if (password.equals(password1)) return true;
        return false;
    }

    @Override
    public void deleteRedis(HttpServletRequest request) {
        // 1. 从请求头获取token
        String token = request.getHeader("headerusertoken");
            // 3. 删除Redis中的用户缓存
            String userKey = REDIS_ADMIN_INFO + ":" + token;
            redis.del(userKey);
        }
}
