package com.mickey.service.impl.rag;

import cn.hutool.json.JSONUtil;
import com.mickey.Entity.ChatEntity;
import com.mickey.Entity.ChatResponseEntity;
import com.mickey.enums.SSEMsgType;
import com.mickey.service.rag.ImageService;
import com.mickey.utils.SSEServer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.content.Media;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeType;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.multipart.MultipartFile;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ImageServiceImpl implements ImageService {

    private final ChatClient chatClient;

    // 构造器注入，自动配置方式（推荐）
    public ImageServiceImpl(ChatClient.Builder chatClientBuilder, ToolCallbackProvider tools, ChatMemory chatMemory) {

        this.chatClient = chatClientBuilder
                .defaultOptions(ChatOptions.builder().model("qwen-omni-turbo-latest").build())
                .defaultToolCallbacks(tools)
                .defaultAdvisors(MessageChatMemoryAdvisor.builder(chatMemory).build())
//                .defaultSystem(systemPrompt)
                .build()
        ;
    }

    public void analyzeImage(List<MultipartFile> files, ChatEntity chatEntity) {
        String userId = chatEntity.getCurrentUserName();
        String prompt = chatEntity.getMessage();
        String botMsgId = chatEntity.getBotMsgId();

        // 1. 处理图片
        List<Media> medias = files.stream()
                .map(file -> new Media(
                        MimeType.valueOf(file.getContentType()),
                        file.getResource()))
                .toList();

        // 2. 多模态
        Flux<String> stringFlux = chatClient.prompt()
                .user(p -> p.text(prompt).media(medias.toArray(Media[]::new)))
                .advisors(p -> p.param(ChatMemory.CONVERSATION_ID, userId)) // 会话记忆分离
                .stream()
                .content();

        List<String> list = stringFlux.toStream().map(chatResponse -> {
            String content = chatResponse.toString();
            SSEServer.sendMsg(userId, content, SSEMsgType.ADD);
            log.info("content: {}", content);
            return content;
        }).collect(Collectors.toList());

        String fullContent = list.stream().collect(Collectors.joining());

        ChatResponseEntity chatResponseEntity = new ChatResponseEntity(fullContent, botMsgId);

        SSEServer.sendMsg(userId, JSONUtil.toJsonStr(chatResponseEntity), SSEMsgType.FINISH);
    }
}