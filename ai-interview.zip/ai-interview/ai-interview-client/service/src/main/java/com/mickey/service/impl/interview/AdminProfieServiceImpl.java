package com.mickey.service.impl.interview;

import com.mickey.DTO.AdminInfoDTO;
import com.mickey.DTO.ChangePasswordDTO;
import com.mickey.Entity.AdminInfo;
import com.mickey.VO.AdminInfoVO;
import com.mickey.grace.result.GraceJSONResult;
import com.mickey.grace.result.ResponseStatusEnum;
import com.mickey.mapper.RegisterMapper;
import com.mickey.mapper.RegisterMapperCustom;
import com.mickey.service.interview.AdminLoginService;
import com.mickey.service.interview.AdminProfileService;
import com.mickey.utils.JsonUtils;
import com.mickey.utils.RedisOperator;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDate;

import static com.mickey.base.BaseInfoProperties.REDIS_ADMIN_INFO;

@Slf4j
@Service
public class AdminProfieServiceImpl implements AdminProfileService {
    @Resource
    private RegisterMapperCustom registerMapperCustom;
    @Resource
    private RegisterMapper registerMapper;
    @Resource
    private RedisOperator redis;
    @Autowired
    private AdminLoginService adminLoginService;

    @Override
    public AdminInfoVO updateProfile(HttpServletRequest request, AdminInfoDTO updateInfoDTO) {
        // 1. 根据用户名查询原始数据
        String username = updateInfoDTO.getUsername();
        AdminInfo originalInfo = registerMapperCustom.selectAdminInfoByName(username);
        // 2. 更新可修改字段（前端已限制修改username/createdAt）
        originalInfo.setRealName(updateInfoDTO.getRealName());
        originalInfo.setMobile(updateInfoDTO.getMobile());
        originalInfo.setEmail(updateInfoDTO.getEmail());
        originalInfo.setSex(updateInfoDTO.getSex());
        originalInfo.setBirthday(updateInfoDTO.getBirthday());
        originalInfo.setUpdatedAt(LocalDate.now());
        registerMapper.updateById(originalInfo);
        AdminInfoVO updatedInfoVO = new AdminInfoVO();
        BeanUtils.copyProperties(originalInfo, updatedInfoVO);

        String token = request.getHeader("headerusertoken");
        String redisKey = REDIS_ADMIN_INFO + ":" + token;
        String adminInfoJson = redis.get(redisKey);
        if (adminInfoJson == null) {
            return null;
        }

        redis.set(REDIS_ADMIN_INFO + ":" + token, JsonUtils.objectToJson(updatedInfoVO), 3 * 60 * 60);
        return updatedInfoVO;
    }

    @Override
    public AdminInfoVO setProfile(HttpServletRequest request) {
        // 1. 获取并验证token
        String token = request.getHeader("headerusertoken");
        // 2. 从Redis获取管理员信息
        String redisKey = REDIS_ADMIN_INFO + ":" + token;
        String adminInfoJson = redis.get(redisKey);
        if (adminInfoJson == null) {
            return null;
        }
        // 3. 转换JSON为AdminInfoVO对象
        AdminInfoVO adminInfoVO = JsonUtils.jsonToPojo(adminInfoJson, AdminInfoVO.class);

        // 4. 移除敏感信息(密码)后返回
        adminInfoVO.setPassword(null);
        return adminInfoVO;
    }

    @Override
    public Integer changePassword(HttpServletRequest request, ChangePasswordDTO changePasswordDTO) {
        String username = changePasswordDTO.getUsername();
        AdminInfo adminInfo = registerMapperCustom.selectAdminInfoByName(username);
        // 1. 验证旧密码是否正确
        if (!adminInfo.getPassword().equals(changePasswordDTO.getPassword())) {
            return 1;
        }
        // 2. 旧密码和新密码不能一致
        if (changePasswordDTO.getNewPassword().
                equals(adminInfo.getPassword())) {
            return 2;
        }
        // 3. 验证确认密码一致
        if (!changePasswordDTO.getNewPassword().
                equals(changePasswordDTO.getConfirmPassword())) {
            return 3;
        }
        adminInfo.setPassword(changePasswordDTO.getNewPassword());
        registerMapper.updateById(adminInfo);
        adminLoginService.deleteRedis(request);
        return 4;
    }
}
