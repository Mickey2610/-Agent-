package com.mickey.service.interview;

import com.mickey.DTO.CandidateDTO;
import com.mickey.Entity.Candidate;
import com.mickey.utils.PagedGridResult;

public interface CandidateService {

    void createOrUpdate(CandidateDTO candidateDTO);

    PagedGridResult queryList(String realName, String mobile, Integer page, Integer pageSize);

    void delete(String id);

    Candidate getDetail(String id);

    Candidate queryMobileIsExist(String mobile);
}
