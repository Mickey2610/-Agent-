package com.mickey.service.interview;

import com.mickey.VO.CandidateReportVO;
import com.mickey.VO.CandidateVO;
import com.mickey.VO.ExcelDataVO;
import com.mickey.VO.Top10VO;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.time.LocalDate;
import java.util.List;


public interface AnalysisService {
    //    void getRecentCandidateGrowth();
    Top10VO getInterviewTopScores(LocalDate begin, LocalDate end);

    CandidateReportVO getCandidateReport(LocalDate begin, LocalDate end);

    XSSFWorkbook exportAnalysisReport(LocalDate begin, LocalDate end) throws Exception;
}
