package com.mickey.service.impl.interview;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.mickey.DTO.InterviewerDTO;
import com.mickey.Entity.Interviewer;
import com.mickey.exception.GraceException;
import com.mickey.grace.result.ResponseStatusEnum;
import com.mickey.mapper.InterviewerMapper;
import com.mickey.service.interview.InterviewerService;
import com.mickey.service.interview.JobService;
import com.mickey.service.interview.QuestionLibService;
import jakarta.annotation.Resource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @ClassName InterviewerServiceImpl
 * @Author 公众号【风间影月】
 * @Version 1.0
 * @Description InterviewerServiceImpl
 **/
@Service
public class InterviewerServiceImpl implements InterviewerService {

    @Resource
    private InterviewerMapper interviewerMapper;

    @Resource
    private JobService jobService;

    @Resource
    private QuestionLibService questionLibService;

    @Override
    public void createOrUpdate(InterviewerDTO interviewerDTO) {

        Interviewer interviewer = new Interviewer();
        BeanUtils.copyProperties(interviewerDTO, interviewer);
        interviewer.setUpdatedTime(LocalDateTime.now());

        if (StringUtils.isBlank(interviewer.getId())) {
            interviewer.setCreateTime(LocalDateTime.now());
            interviewerMapper.insert(interviewer);
        } else {
            interviewerMapper.updateById(interviewer);
        }

    }

    @Override
    public List<Interviewer> queryAll() {
        return interviewerMapper.selectList(
                new QueryWrapper<Interviewer>()
                        .orderByDesc("updated_time")
        );
    }

    @Override
    public void delete(String interviewerId) {

        // 删除面试官之前需要判断有没有职位和面试题库正在使用（多表关联需要删除关联的数据）
        boolean jobFlag = jobService.isJobContainInterviewer(interviewerId);
        boolean questionFlag = questionLibService.isQuestionContainInterviewer(interviewerId);

        if (jobFlag || questionFlag) {
            GraceException.display(ResponseStatusEnum.CAN_NOT_DELETE_INTERVIEWER);
        }

        interviewerMapper.deleteById(interviewerId);
    }



}
