package com.mickey.service.interview;

import com.mickey.Entity.AdminInfo;

import java.util.List;

public interface AdminMngService {
    List<AdminInfo> queryAllAdminInfo();
    void delete(String username);
    void updateStatus(String username, Boolean isEnabled);
}
