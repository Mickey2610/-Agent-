package com.mickey.DTO;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class SubmitAnswerDTO implements Serializable {

    private String candidateId;
    private String jobId;
    private List<AnswerDTO> questionAnswerList;
    private Integer totalSeconds;

}
