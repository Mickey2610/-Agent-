package com.mickey.DTO;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CandidateDTO implements Serializable {

    private String id;

    @NotBlank
    private String jobId;

    @NotBlank
    private String realName;

    @NotBlank
    private String identityNum;

    @NotBlank
    private String mobile;

    private Integer sex;

    @NotBlank
    private String email;

    private LocalDate birthday;

}
