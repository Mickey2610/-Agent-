package com.mickey.VO;

import lombok.*;

import java.io.Serializable;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ExcelDataVO implements Serializable {
    private Integer TotalCandidateNum;
    private String nameList;
}
