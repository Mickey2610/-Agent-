package com.mickey.VO;

import lombok.*;

import java.io.Serializable;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CandidateReportVO implements Serializable {
    private String dataList;
    private String totalCandidateList;
    private String newCandidateList;
}
