package com.mickey.DTO;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * <p>
 * 数字人面试官表
 * </p>
 *
 * @author Mickey
 * @since 2025-06-11
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class InterviewerDTO implements Serializable {

    private String id;

    @NotBlank(message = "数字人面试官的名称不能为空")
    private String aiName;

    @NotBlank(message = "数字人面试官的形象图不能为空")
    private String image;

}
