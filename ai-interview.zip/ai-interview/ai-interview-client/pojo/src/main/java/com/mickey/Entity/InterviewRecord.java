package com.mickey.Entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 面试记录表
 * </p>
 *
 * @author Mickey
 * @since 2025-06-11
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@TableName("interview_record")
public class InterviewRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;

    /**
     * 应聘者id
     */
    private String candidateId;

    /**
     * 职位名称，快照名称，原字段可能会更改
     */
    private String jobName;

    /**
     * 应聘者的回答内容
     */
    private String answerContent;

    /**
     * 整个面试所花费的总时间，单位：秒
     */
    private Integer takeTime;

    /**
     * 面试结果详情
     */
    private String result;

    private Integer score;
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDateTime createTime;
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDateTime updatedTime;
}
