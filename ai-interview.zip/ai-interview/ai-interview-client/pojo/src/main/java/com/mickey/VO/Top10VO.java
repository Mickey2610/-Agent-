package com.mickey.VO;

import lombok.*;

import java.io.Serializable;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Top10VO implements Serializable {
    private String nameList;
    private String scoreList;

}
