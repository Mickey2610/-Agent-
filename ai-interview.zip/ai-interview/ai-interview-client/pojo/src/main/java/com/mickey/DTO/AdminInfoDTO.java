package com.mickey.DTO;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDate;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class AdminInfoDTO implements Serializable {
    private String username;
    private String realName;
    private String mobile;
    private String email;
    private String password;
    private String confirmPassword;
    private Integer sex;
    private LocalDate birthday;
}