package com.mickey.DTO;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class AdminLoginDTO implements Serializable {

    @NotBlank
    private String username;
    @NotBlank
    private String password;

}
