package com.mickey.VO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class InitQuestionLibVO {

    private String id;

    private String question;

    private String referenceAnswer;

    private String aiSrc;

    private String interviewerId;
}
