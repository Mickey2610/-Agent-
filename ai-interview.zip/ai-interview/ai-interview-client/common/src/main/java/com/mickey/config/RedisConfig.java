package com.mickey.config;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.ai.embedding.EmbeddingModel;
//import org.springframework.ai.transformers.TransformersEmbeddingModel;
import org.springframework.ai.vectorstore.redis.RedisVectorStore;
import org.springframework.ai.vectorstore.redis.autoconfigure.RedisVectorStoreAutoConfiguration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import redis.clients.jedis.JedisPooled;

import java.time.Duration;

@Configuration
@EnableCaching
public class RedisConfig {

    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory factory) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(factory);

        // 解决 Jackson2 无法反序列化 LocalDateTime 的问题
        ObjectMapper om = new ObjectMapper();
        om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        om.activateDefaultTyping(om.getPolymorphicTypeValidator(), ObjectMapper.DefaultTyping.NON_FINAL);
        om.registerModule(new JavaTimeModule());
        om.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        // 使用 GenericJackson2JsonRedisSerializer（替代已弃用的 setObjectMapper）
        GenericJackson2JsonRedisSerializer serializer = new GenericJackson2JsonRedisSerializer(om);

        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(serializer);
        template.setHashKeySerializer(new StringRedisSerializer());
        template.setHashValueSerializer(serializer);
        template.afterPropertiesSet();
        return template;
    }

    @Value("${mickey.redis.domain}")
    private String redisDomain;
    @Value("${mickey.redis.port}")
    private Integer redisPort;
//    @Value("${spring.ai.model.embedding}")
//    private String embedding;
//    @Bean
//    public EmbeddingModel embeddingModel() {
//        // 确保系统能找到 DLL 文件
//        System.setProperty("jna.library.path", embedding);
//        return new TransformersEmbeddingModel();
//    }
    @Bean
    public CacheManager cacheManager(RedisConnectionFactory factory) {
        RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig()
                .serializeKeysWith(RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer()))
                .serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer()))
                .entryTtl(Duration.ofHours(1)); // 设置缓存过期时间

        return RedisCacheManager.builder(factory)
                .cacheDefaults(config)
                .build();
    }

    @Configuration
    public class RedisVectorStoreConfig {

        @Bean
        public JedisPooled jedisPooled() {
            return new JedisPooled(redisDomain, redisPort, "default", "mq20011103");
        }

        @Bean
        public RedisVectorStore redisVectorStore(
                JedisPooled jedisPooled,
                EmbeddingModel embeddingModel) {

            return RedisVectorStore.builder(jedisPooled, embeddingModel)
                    .indexName("spring-ai-index")  // 使用错误中显示的索引名
                    .prefix("embedding:")
                    .initializeSchema(true)  // 关键配置：强制初始化索引
                    .build();
        }
    }
}