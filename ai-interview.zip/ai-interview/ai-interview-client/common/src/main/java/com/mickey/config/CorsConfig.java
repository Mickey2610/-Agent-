package com.mickey.config;

import lombok.extern.slf4j.Slf4j;
import com.mickey.interceptor.JwtTokenAdminInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 统一配置类：包含 CORS 设置和拦截器注册
 */
@Configuration
@Slf4j
public class CorsConfig implements WebMvcConfigurer {

    @Autowired
    private JwtTokenAdminInterceptor jwtTokenAdminInterceptor;

    // 从 application.yml 中读取前端域名
    @Value("${mickey.frontend.domain}")
    private String frontendDomain;

    /**
     * 配置跨域请求（CORS）
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // 所有接口都允许跨域访问
                .allowedOrigins(frontendDomain) // 允许的来源（来自配置文件）
                .allowedMethods("*") // 允许的方法（GET, POST 等）
                .allowedHeaders("*") // 允许的头部
                .allowCredentials(true) // 是否允许发送 Cookie
                .maxAge(3600); // 预检请求缓存时间（OPTIONS 请求）
    }

    /**
     * 注册自定义拦截器
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        log.info("开始注册 admin 自定义拦截器...");
        registry.addInterceptor(jwtTokenAdminInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns(
                        "/admin/login",
                        "/admin/logout",
                        "/speech/**",
                        "/welcome/**",
                        "/questionLib/prepareQuestion",
                        "/interviewRecord/**",
                        "/hello/**",
                        "/sse/**",
                        "/sse",
                        "/register/**"
                );
    }
}