package com.mickey.utils;

public class BaiduAISDK {

    public static final String APP_ID = "119365633";
    public static final String API_KEY = "H3UBNVSxTNuWTVmIo9Ozti4Q";
    public static final String SECRET_KEY = "4EAsMKaG8c3akhV7T7Ut5Eb2IYkgQNT1";

}
