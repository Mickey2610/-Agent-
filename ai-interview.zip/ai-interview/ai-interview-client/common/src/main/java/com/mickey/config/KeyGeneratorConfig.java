package com.mickey.config;

import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;

@Configuration
public class KeyGeneratorConfig {
    @Bean("interviewRecordKeyGenerator")
    public KeyGenerator interviewRecordKeyGenerator() {
        return (target, method, params) -> {
            // 假设 list 接口参数顺序为: realName, mobile, page, pageSize
            if (params.length >= 4 &&
                    params[0] instanceof String &&
                    params[1] instanceof String &&
                    params[2] instanceof Integer &&
                    params[3] instanceof Integer) {

                String realName = (String) params[0];
                String mobile = (String) params[1];
                Integer page = (Integer) params[2];
                Integer pageSize = (Integer) params[3];

                return String.format("interviewRecord:list:%s:%s:%d:%d", realName, mobile, page, pageSize);
            }

            // 默认回退策略
            return method.getName() + ":" + Arrays.asList(params).toString();
        };
    }


    @Bean("adminMngKeyGenerator")
    public KeyGenerator adminMngKeyGenerator() {
        return (target, method, params) -> {
            StringBuilder keyBuilder = new StringBuilder("AdminMng:");

            keyBuilder.append(method.getName());

            if (params != null && params.length > 0) {
                for (Object param : params) {
                    if (param instanceof String) {
                        keyBuilder.append(":").append(param);
                    }
                }
            } else {
                keyBuilder.append(":all");
            }

            String key = keyBuilder.toString();
            System.out.println("Generated AdminMng Cache Key: " + key); // 可选：打印 key
            return key;
        };
    }
}
