package com.mickey.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mickey.Entity.Candidate;
import com.mickey.VO.CandidateVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 应聘者表 Mapper 接口
 * </p>
 *
 * @author Mickey
 * @since 2025-06-11
 */
public interface CandidateMapperCustom {

    public List<CandidateVO> queryCandidateList(@Param("paramMap") Map<String, Object> map);
    public Candidate selectCandidateByMobile(String mobile);

}
