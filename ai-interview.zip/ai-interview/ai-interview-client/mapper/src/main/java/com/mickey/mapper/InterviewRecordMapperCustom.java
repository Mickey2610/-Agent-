package com.mickey.mapper;

import com.mickey.DTO.Top10DTO;
import com.mickey.VO.InterviewRecordVO;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public interface InterviewRecordMapperCustom {

    public List<InterviewRecordVO> queryList(@Param("paramMap") Map<String, Object> map);
    public List<Top10DTO> getInterviewTop10(
            @Param("beginTime") LocalDateTime beginTime,
            @Param("endTime") LocalDateTime endTime
    );
}
