package com.mickey.mapper;

import com.mickey.Entity.AdminInfo;

public interface RegisterMapperCustom {
    AdminInfo selectAdminInfoByName(String username);
}
