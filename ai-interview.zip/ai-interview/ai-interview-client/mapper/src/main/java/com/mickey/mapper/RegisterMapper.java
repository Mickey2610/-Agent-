package com.mickey.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mickey.Entity.AdminInfo;

public interface RegisterMapper extends BaseMapper<AdminInfo> {

}
