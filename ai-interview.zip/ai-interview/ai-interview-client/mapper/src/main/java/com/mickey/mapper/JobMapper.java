package com.mickey.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mickey.Entity.Job;

/**
 * <p>
 * 职位信息表 Mapper 接口
 * </p>
 *
 * @author Mickey
 * @since 2025-06-11
 */
public interface JobMapper extends BaseMapper<Job> {

}
