package com.mickey.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mickey.Entity.Job;
import com.mickey.VO.JobVO;
import com.mickey.VO.QuestionLibVO;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 职位信息表 Mapper 接口
 * </p>
 *
 * @author Mickey
 * @since 2025-06-11
 */
public interface JobMapperCustom {
    public List<JobVO> queryJobLibList(@Param("paramMap") Map<String, Object> map);

    public List<HashMap<String, String>> queryNameList(@Param("paramMap") Map<String, Object> map);
}
